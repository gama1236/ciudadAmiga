import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privado-page',
  templateUrl: './privado-page.component.html',
  styleUrls: ['./privado-page.component.scss']
})
export class PrivadoPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
