import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bot-found-page',
  templateUrl: './bot-found-page.component.html',
  styleUrls: ['./bot-found-page.component.scss']
})
export class BotFoundPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
